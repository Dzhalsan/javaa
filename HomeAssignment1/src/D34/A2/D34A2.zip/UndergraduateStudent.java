package D34.A2;

public class UndergraduateStudent extends Student{

    public UndergraduateStudent(String name) {

        super(name);

    }
}
