package D34.A2;

public class GraduateStudent extends Student{

    public GraduateStudent(String name) {

        super(name);

    }
}
