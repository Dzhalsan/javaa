package D34.A2;

public class Student {

    String name;
    int studentId;

    public Student(String name) {

        this.name = name;

    }
}
